# launchpadi.com Sitemaps — 2026-09-03
| Sitemap | Type | Submitted | Last read | Status | Discovered pages | Videos |
|---|---|---|---|---|---|---|
| https://www.launchpadi.com/sitemap.xml | Sitemap | 29 Jul 2026 | 1 Sept 2026 | Success | 143 | 0 |
Only 1 submitted sitemap (1-1 of 1). No errors.
